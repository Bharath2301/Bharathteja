TITLE:
Personal Portfolio Template built by Gulam Anas https://twitter.com/_gulam_anas_

AUTHOR:
DESIGNED & DEVELOPED by Gulam Anas

CREDITS:

Scroll Animation
https://michalsnik.github.io/aos/

Demo Images:
http://unsplash.com

Folder Contains:

- index.html file for all markup
- css/style.css for all custom css
- css/aos.css mandatory for scroll animation
- css/fontawesome-all.min.css for font-awesome icons
- js/app.js for custom scripts
- js/aos.js mandatory for scroll animation
- assets folder for all required images
- assets/tech-assets for all tech tools icon
- webfonts folder mandatory for fontawesome icons